package com.sbp.ollamaExemple.service;

import com.sbp.ollamaExemple.model.ChatMessage;
import com.sbp.ollamaExemple.model.Conversation;
import com.sbp.ollamaExemple.repository.ConversationRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class ConversationService {

    private final ConversationRepository conversationRepository;

    public String startNewConversation(String personality) {
        Conversation conversation = new Conversation();
        conversation.setKey(UUID.randomUUID().toString());
        conversation.setPersonality(personality);
        conversationRepository.save(conversation);
        return conversation.getKey();
    }

    public Optional<Conversation> findConversationByKey(String key) {
        return conversationRepository.findByKey(key);
    }

    public void addMessageToConversation(String conversationKey, ChatMessage message) {
        Optional<Conversation> conversationOpt = findConversationByKey(conversationKey);
        if (conversationOpt.isPresent()) {
            Conversation conversation = conversationOpt.get();
            conversation.getMessages().add(message);
            conversationRepository.save(conversation);
        } else {
            throw new IllegalArgumentException("Conversation with key " + conversationKey + " not found");
        }
    }

    public void setConversationSetting(String conversationId, String key, String value) {
        Optional<Conversation> conversationOpt = conversationRepository.findByKey(conversationId);
        if (conversationOpt.isPresent()) {
            Conversation conversation = conversationOpt.get();
            conversation.getSettings().put(key, value);
            conversationRepository.save(conversation);
        } else {
            throw new IllegalArgumentException("Conversation with ID " + conversationId + " not found.");
        }
    }

    public String getConversationSetting(String conversationId, String key) {
        Optional<Conversation> conversationOpt = conversationRepository.findByKey(conversationId);
        if (conversationOpt.isPresent()) {
            Conversation conversation = conversationOpt.get();
            return conversation.getSettings().getOrDefault(key, "Setting not found");
        } else {
            return "Conversation not found";
        }
    }

    public String handleUserInput(String conversationId, String userMessage) {
        Optional<Conversation> conversationOpt = conversationRepository.findByKey(conversationId);
        if (conversationOpt.isEmpty()) {
            throw new IllegalArgumentException("Conversation not found.");
        }

        Conversation conversation = conversationOpt.get();
        // Simuler une réponse
        String response = "Réponse simulée pour : " + userMessage;

        ChatMessage userMsg = new ChatMessage();
        userMsg.setSender("User");
        userMsg.setContent(userMessage);
        conversation.getMessages().add(userMsg);

        ChatMessage aiMsg = new ChatMessage();
        aiMsg.setSender("AI");
        aiMsg.setContent(response);
        conversation.getMessages().add(aiMsg);

        conversationRepository.save(conversation);
        return response;
    }
}
