package com.sbp.ollamaExemple.service;

import com.sbp.ollamaExemple.model.ChatMessage;
import com.sbp.ollamaExemple.model.Conversation;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@RequiredArgsConstructor
public class ChatBotService {

    private final ConversationService conversationService;

    public String getResponse(String conversationKey, String userMessage) {
        Optional<Conversation> conversationOpt = conversationService.findConversationByKey(conversationKey);
        if (conversationOpt.isEmpty()) {
            throw new IllegalArgumentException("Conversation not found with key: " + conversationKey);
        }

        Conversation conversation = conversationOpt.get();

        // Ajout du message utilisateur à la conversation
        ChatMessage userMsg = new ChatMessage();
        userMsg.setSender("User");
        userMsg.setContent(userMessage);
        conversationService.addMessageToConversation(conversationKey, userMsg);

        // Génération d'une réponse simulée
        String aiResponse = "Simulated response for: " + userMessage;

        // Ajout de la réponse AI à la conversation
        ChatMessage aiMsg = new ChatMessage();
        aiMsg.setSender("AI");
        aiMsg.setContent(aiResponse);
        conversationService.addMessageToConversation(conversationKey, aiMsg);

        return aiResponse;
    }
}
