package com.sbp.ollamaExemple.controller;

import com.sbp.ollamaExemple.service.ConversationService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/conversations")
public class OllamaCallController {

    private final ConversationService conversationService;

    @PostMapping("/start")
    public String startConversation(@RequestParam(required = false) String personality) {
        return conversationService.startNewConversation(personality);
    }

    @PostMapping("/{conversationId}/configure")
    public void configureConversation(
            @PathVariable String conversationId,
            @RequestParam String key,
            @RequestParam String value
    ) {
        conversationService.setConversationSetting(conversationId, key, value);
    }

    @GetMapping("/{conversationId}/setting")
    public String getConversationSetting(
            @PathVariable String conversationId,
            @RequestParam String key
    ) {
        return conversationService.getConversationSetting(conversationId, key);
    }

    @PostMapping("/{conversationId}/message")
    public String handleMessage(
            @PathVariable String conversationId,
            @RequestParam String question
    ) {
        return conversationService.handleUserInput(conversationId, question);
    }
}
