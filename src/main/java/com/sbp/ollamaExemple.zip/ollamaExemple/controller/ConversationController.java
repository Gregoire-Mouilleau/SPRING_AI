package com.sbp.ollamaExemple.controller;

import com.sbp.ollamaExemple.service.ConversationService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/conversations")
@RequiredArgsConstructor
public class ConversationController {

    private final ConversationService conversationService;

    @PostMapping("/start")
    public Map<String, String> startConversation(@RequestBody Map<String, String> body) {
        String personality = body.get("personality");
        if (personality == null || personality.isEmpty()) {
            throw new IllegalArgumentException("Personality must be provided.");
        }
        String conversationKey = conversationService.startNewConversation(personality);
        return Map.of("conversationKey", conversationKey);
    }
}
