package com.sbp.ollamaExemple.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import com.sbp.ollamaExemple.service.ChatBotService;

@RestController
@RequestMapping("/api/chat")
@RequiredArgsConstructor
public class ChatBotController {

    private final ChatBotService chatBotService;

    @PostMapping("/{key}/message")
    public String useChatBot(@PathVariable String key, @RequestParam String userMessage) {
        return chatBotService.getResponse(key, userMessage);
    }
}
